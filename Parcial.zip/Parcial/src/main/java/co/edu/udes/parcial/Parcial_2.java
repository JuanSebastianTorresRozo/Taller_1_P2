/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.parcial;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Parcial_2 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite el dia:");
        int dia = entrada.nextInt();

        System.out.println("Digite el mes:");
        int mes = entrada.nextInt();

        System.out.println("Digite el año:");
        int año = entrada.nextInt();

        boolean fechaValida = true;
        if (mes < 1 || mes > 12) {
            fechaValida = false;
        } else {
            int diasMax;
            if (mes == 2) {
                if (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0)) {
                    diasMax = 29;
                } else {
                    diasMax = 28;
                }
            } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                diasMax = 30;
            } else {
                diasMax = 31;
            }
            if (dia < 1 || dia > diasMax) {
                fechaValida = false;
            }
        }

        // Mostrar el resultado de la validación
        if (fechaValida) {
            System.out.println("La fecha ingresada es válida.");
        } else {
            System.out.println("La fecha ingresada es inválida.");
        }

    }
}
