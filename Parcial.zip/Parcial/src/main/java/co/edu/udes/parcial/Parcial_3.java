/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.parcial;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Parcial_3 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingresa un número : ");
        int numero = entrada.nextInt();

        boolean apilar = false;
        for (int i = 1; i <= numero; i++) {
            if ((i * (i + 1)) / 2 == numero) {
                apilar = true;
                break;
            }

        }
        if (apilar) {
            System.out.println("El número " + numero + " puede ser apilar");
        } else {
            System.out.println("El número " + numero + " no puede ser apilar");
        }

    }
}
