/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.parcial;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Parcial_4 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Digite la cantidad de numeros de la serie:");
        int serie = entrada.nextInt();

        int a = 0, b = 1;

        System.out.print("La serie de Fibonacci es: ");
        for (int i = 1; i <= serie; i++) {
            System.out.print(a + " ");
            int c = a + b;
            a = b;
            b = c;
        }

    }
}
