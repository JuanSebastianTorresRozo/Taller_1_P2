/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Edificio {
    private String nombre, uso, estilo, equipamiento, servicios;
    private int añoConstruccion, direccion, altura, numeroPisos;
}
