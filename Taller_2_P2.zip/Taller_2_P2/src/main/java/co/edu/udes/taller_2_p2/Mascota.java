/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Mascota {
    private String nombre, alimentacion, especie, raza, color, genero, comportamiento, cuidados;
    private int edad, tamaño, peso;
}
