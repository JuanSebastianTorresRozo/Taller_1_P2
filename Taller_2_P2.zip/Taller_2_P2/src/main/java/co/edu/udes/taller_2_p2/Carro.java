/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Carro {

    private String modelo, marca,color,transmision,combustible;
    private int placa,año,kilometraje,motor,velocidadMaxima;
}
