/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Asignatura {
    private String nombre, profesor, temario,objetivos, requisitosPrevios;
    private int horasSemanales, creditos, horasTotales, notas;
}
