/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package co.edu.udes.parcial;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Parcial {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("digite la cantidad de segundos:");
        int segundos = entrada.nextInt();

        int horas = segundos / 3600;
        int minutos = (segundos % 3600) / 60;
        int totalSegundos = segundos % 60;

        System.out.println(segundos + " segundos equivalen a " + horas + " horas, " + minutos + " minutos y " + totalSegundos + " segundos.");
    }

}

