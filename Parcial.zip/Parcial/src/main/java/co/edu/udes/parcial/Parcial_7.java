/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.parcial;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Parcial_7 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Introduce el tamaño de los vectores: ");
        int tamano = entrada.nextInt();

        int[] vector1 = new int[tamano];
        int[] vector2 = new int[tamano];

        System.out.println("Introduce los valores del primer vector:");
        for (int i = 0; i < tamano; i++) {
            vector1[i] = entrada.nextInt();
        }
        System.out.println("Introduce los valores del segundo vector:");
        for (int i = 0; i < tamano; i++) {
            vector2[i] = entrada.nextInt();
        }

        int[] vector3 = new int[2 * tamano];
        int i = 0, j = 0, k = 0;
        while (i < tamano && j < tamano) {
            if (vector1[i] < vector2[j]) {
                vector3[k] = vector1[i];
                i++;
            } else {
                vector3[k] = vector2[j];
                j++;
            }
            k++;
        }
        while (i < tamano) {
            vector3[k] = vector1[i];
            i++;
            k++;
        }
        while (j < tamano) {
            vector3[k] = vector2[j];
            j++;
            k++;
        }

        System.out.println("El vector fusionado y ordenado es:");
        for (i = 0; i < 2 * tamano; i++) {
            System.out.print(vector3[i] + " ");
        }
    }
}
