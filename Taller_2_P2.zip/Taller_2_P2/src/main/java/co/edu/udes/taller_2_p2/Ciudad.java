/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Ciudad {
    private String nombre, pais, clima, idioma, servicios;
    private int poblacion, fundacion;
}
