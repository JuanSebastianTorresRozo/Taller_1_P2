/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_2_p2;

/**
 *
 * @author Sebas
 */
public class Empresa {
    private String nombre, razonSocial, actividad, estrategia, mision, vision;
    private int capital, añoFundacion, empleados, direccion, telefono, numeroIdentificacion;
}
